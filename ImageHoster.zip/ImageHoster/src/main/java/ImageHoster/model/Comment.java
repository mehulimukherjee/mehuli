package ImageHoster.model;

import java.time.LocalDate;

import javax.persistence.*;

@Entity
@Table(name = "comments")
public class Comment {
	@Column(name="id")
	private Integer id;
	@Column(name="text")
	private String text;
	@Column(name="createdDate")
	private LocalDate createdDate;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id")
	private User user;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "image_id")
	private Image image;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public Comment(User user, Image image) {
		super();
		this.user = user;
		this.image = image;
	}

	public Comment(Integer id, String text, LocalDate createdDate, User user, Image image) {
		super();
		this.id = id;
		this.text = text;
		this.createdDate = createdDate;
		this.user = user;
		this.image = image;
	}
	
}
